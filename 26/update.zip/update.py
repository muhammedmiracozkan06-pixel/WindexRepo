#!/usr/bin/env python3
"""WindexUpdate TEST update.py
root olarak çalışır; normal kullanıcıların masaüstünde "test" klasörü oluşturur."""
import os, pwd, re, subprocess, sys, time


def progress(n):
    subprocess.run(["windexupdate", "progress", str(n)])


def finish(ok, message=""):
    subprocess.run(["windexupdate", "updateended",
                    "conclusion=" + ("Successful" if ok else "Failed"),
                    "message=" + message])
    sys.exit(0 if ok else 1)


def desktop_of(user):
    """Kullanıcının masaüstü yolunu bulur (XDG ayarı, yoksa Desktop / Masaüstü)."""
    home = user.pw_dir
    try:
        txt = open(f"{home}/.config/user-dirs.dirs").read()
        m = re.search(r'XDG_DESKTOP_DIR="([^"]+)"', txt)
        if m:
            return m.group(1).replace("$HOME", home)
    except OSError:
        pass
    for name in ("Desktop", "Masaüstü"):
        p = os.path.join(home, name)
        if os.path.isdir(p):
            return p
    return os.path.join(home, "Desktop")


try:
    progress(10)
    users = [u for u in pwd.getpwall()
             if 1000 <= u.pw_uid < 60000 and os.path.isdir(u.pw_dir)]
    if not users:
        finish(False, "Normal kullanıcı bulunamadı")

    done = 0
    for i, u in enumerate(users, 1):
        desk = desktop_of(u)
        os.makedirs(desk, exist_ok=True)
        os.chown(desk, u.pw_uid, u.pw_gid) if not os.listdir(desk) else None
        folder = os.path.join(desk, "test")
        os.makedirs(folder, exist_ok=True)
        with open(os.path.join(folder, "update-test.txt"), "w") as f:
            f.write("WindexUpdate test güncellemesi başarılı.\n"
                    + time.strftime("%d/%m/%Y %H:%M:%S") + "\n")
        for p in (folder, os.path.join(folder, "update-test.txt")):
            os.chown(p, u.pw_uid, u.pw_gid)
        done += 1
        progress(10 + 80 * i // len(users))
        time.sleep(1)  # ilerleme çubuğunu görmek için

    progress(95)
    finish(True, f"{done} kullanıcının masaüstüne test klasörü eklendi")
except Exception as e:
    finish(False, str(e))
